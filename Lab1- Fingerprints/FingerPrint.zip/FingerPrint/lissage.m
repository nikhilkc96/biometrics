function y = lissage(x)
m=sum(x(:));
if m>3
    y=1;
else
    y=0;
end